using Content.Shared._Persistence14.Dependencies;
using JetBrains.Annotations;
using Robust.Shared.Prototypes;

namespace Content.Shared._Persistence14.Allergy;

/// <summary>
/// Used by AllergyPrototype and other items to select one or more allergens for use in an allergy profile.
/// </summary>
[ImplicitDataDefinitionForInheritors, UsedImplicitly(ImplicitUseTargetFlags.WithInheritors)]
public abstract partial class AllergenSelector
{
    [DataField]
    public float Threshold = 0f;

    public abstract IEnumerable<ProtoId<AllergenPrototype>> GetAllergens(ContextDependencies dependencies, AllergyContext ctx);
}