namespace Content.Shared._Persistence14.Allergy;

[DataDefinition]
public sealed partial class AllergenProfile
{
    /// <summary>
    /// Determines the degree to which the allergen exposure is multiplied when this allergen is present.
    /// </summary>
    [DataField]
    public float IntensityMultipler = 1f;
}