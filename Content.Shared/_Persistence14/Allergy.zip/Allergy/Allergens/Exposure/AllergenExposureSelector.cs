using Content.Shared._Persistence14.Dependencies;
using JetBrains.Annotations;

namespace Content.Shared._Persistence14.Allergy;

[ImplicitDataDefinitionForInheritors, UsedImplicitly(ImplicitUseTargetFlags.WithInheritors)]
public abstract partial class AllergenExposureSelector
{
    public abstract bool Exposed(ContextDependencies dependencies, AllergyContext ctx);
}