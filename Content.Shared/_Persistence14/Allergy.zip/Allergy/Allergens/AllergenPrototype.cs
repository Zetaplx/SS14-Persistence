using Robust.Shared.Prototypes;

namespace Content.Shared._Persistence14.Allergy;

[Prototype]
public sealed partial class AllergenPrototype : IPrototype
{
    [IdDataField]
    public string ID { get; set; } = default!;

    [IncludeDataField]
    public AllergenProfile Profile = default!;

    [DataField("exposure")]
    public AllergenExposureSelector ExposureSelector = default!;
}