using Content.Shared._Persistence14.Dependencies;
using Content.Shared.Mobs;
using Robust.Shared.Prototypes;

namespace Content.Shared._Persistence14.Allergy;

/// <summary>
/// The system managing all shared aspects of allergic reactions and allergy detection.
/// </summary>
public sealed partial class AllergySystem : EntitySystem
{
    [Dependency] private IPrototypeManager _protoMan = default!;
    private ContextDependencies? _dependencies;

    public override void Initialize()
    {
        _dependencies = new ContextDependencies();
    }

    public override void Update(float frameTime)
    {
        var allergicEntities = EntityQueryEnumerator<AllergicComponent>();
        var ctx = new AllergyContext();

        while (allergicEntities.MoveNext(out var uid, out var allergicComp))
        {
            DecrementAllergens((uid, allergicComp), frameTime);
            IncrementAllergens(ctx, (uid, allergicComp), frameTime);
        }
    }

    private void DecrementAllergens(Entity<AllergicComponent> ent, float frameTime)
    {
        var activeAllergens = ent.Comp.AllergenExposure.Keys;

        foreach (var allergen in activeAllergens)
        {
            ent.Comp.AllergenExposure[allergen] -= frameTime;
            if (ent.Comp.AllergenExposure[allergen] <= 0f)
                ent.Comp.AllergenExposure.Remove(allergen);
        }
    }

    private void IncrementAllergens(AllergyContext ctx, Entity<AllergicComponent> ent, float frameTime)
    {
        Dictionary<ProtoId<AllergenPrototype>, AllergenPrototype> allergens = new();
        _dependencies ??= new ContextDependencies();

        foreach (var allergy in ent.Comp.Allergies)
        {
            if (!_protoMan.TryIndex(allergy, out var allergyProto))
                continue;

            foreach (var allergen in allergyProto.Allergen.GetAllergens(_dependencies, ctx))
            {
                allergens.TryAdd(allergen, _protoMan.Index(allergen));
            }
        }

        foreach (var (id, allergen) in allergens)
        {
            if (!allergen.ExposureSelector.Exposed(_dependencies, ctx))
                return;

            if (!ent.Comp.AllergenExposure.TryGetValue(id, out var val))
                val = 0;
            ent.Comp.AllergenExposure[id] = frameTime * allergen.Profile.IntensityMultipler + val;
        }
    }
}